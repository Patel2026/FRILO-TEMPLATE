# Design System Specification: The Ethereal Sanctuary

## 1. Overview & Creative North Star
**Creative North Star: The Breathable Canvas**

This design system is not a utility; it is an atmosphere. To design for wellness is to design for the nervous system. We are moving away from the "grid-locked" templates of traditional SaaS and moving toward a **High-End Editorial** experience. 

The "Breathable Canvas" philosophy dictates that white space is a functional element, not a void. We achieve a premium feel through **intentional asymmetry**, where images and typography are allowed to bleed off-center, and **tonal layering**, where depth is felt rather than seen. The goal is to create a digital sanctuary that feels as tactile and high-quality as a linen-bound art book.

---

## 2. Colors & Surface Philosophy
Our palette is rooted in the earth: organic sages (`primary`), warm beiges (`surface`), and muted clays (`tertiary`).

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections or containers. Traditional borders create visual "noise" that interrupts the calming rhythm. 
- Boundaries must be defined solely through **background color shifts**. For example, a `surface-container-low` section should sit adjacent to a `surface` background to create a soft, natural break.
- Use `surface-container-lowest` to make elements feel like they are "receding" and `surface-container-high` to bring them forward.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of handmade paper.
- **Base Layer:** `surface` (#fafaf5).
- **Secondary Content Blocks:** `surface-container-low` (#f3f4ee).
- **Interactive Cards:** `surface-container-lowest` (#ffffff) to provide a "bright" lift against the beige.
- **Nesting:** Never place two containers of the same tier inside each other. Always step up or down the hierarchy to maintain clarity without lines.

### The "Glass & Gradient" Rule
To escape the "flat" look, use Glassmorphism for floating elements (like navigation bars or modals). 
- **Recipe:** Use `surface` at 80% opacity with a `backdrop-filter: blur(20px)`.
- **Signature Gradients:** For Hero sections or primary CTAs, use a subtle radial gradient: `primary` (#526447) transitioning into `primary-container` (#d4e9c4) at a 45-degree angle. This adds "visual soul" and depth.

---

## 3. Typography
The typography is a dialogue between the timeless elegance of the serif and the modern clarity of the sans-serif.

- **Display & Headlines (Noto Serif):** Use these for emotional impact. Noto Serif should be styled with a "light" weight and increased letter spacing (0.02em) to feel airy. Use `display-lg` for hero moments to establish an editorial authority.
- **Body & Labels (Manrope):** Manrope is our functional workhorse. It provides a clean, grounding contrast to the serif. 
- **Hierarchy Hint:** Large `display` type should often be paired with significant white space to allow the letterforms to "breathe." Never crowd a serif headline.

---

## 4. Elevation & Depth
We reject the standard Material Design drop shadow. Depth in this system is achieved through **Tonal Layering** and **Ambient Light**.

### The Layering Principle
Instead of a shadow, place a `surface-container-lowest` card on a `surface-container-low` background. The shift in hex code provides enough contrast for the eye to perceive a "lift" without the "muddiness" of a shadow.

### Ambient Shadows
When a floating effect is non-negotiable (e.g., a floating action button or a dropdown):
- **Blur:** 40px - 60px.
- **Opacity:** 4% - 8%.
- **Color:** Use a tinted version of `on-surface` (#2f342e) rather than pure black. This mimics how light interacts with soft fabrics and matte surfaces.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., a high-contrast mode), use a **Ghost Border**:
- Token: `outline-variant` (#afb3ac).
- Opacity: **Reduced to 15%**. It should be felt as a suggestion of a container, not a rigid cage.

---

## 5. Components

### Buttons
- **Primary:** Pill-shaped (`rounded-full`). Background: `primary`. Text: `on-primary`. Use a subtle 4px vertical shift on hover to simulate a physical press.
- **Secondary:** Pill-shaped. Background: `surface-container-high`. Text: `on-secondary-container`.
- **Tertiary:** Text-only with a 1px underline using the `primary` color, but only appearing on hover.

### Cards & Lists
- **Rule:** Absolute prohibition of divider lines. 
- Use `1.5rem` to `2rem` of vertical padding between list items to create separation.
- Cards should use `rounded-xl` (1.5rem) to maintain a soft, approachable organic shape.

### Input Fields
- Avoid the "boxed-in" look. Use a `surface-container-low` background with a `rounded-md` top and a 1.5pt thick bottom stroke in `primary` when focused.
- Labels (`label-md`) should always be in `on-surface-variant` to reduce visual weight.

### Chips (Serenity Tags)
- Used for filtering wellness categories (e.g., "Yoga," "Meditation"). 
- Styling: `surface-container-high` with `on-surface-variant` text. When selected, transition to `primary-container` and `on-primary-container`.

---

## 6. Do's and Don'ts

### Do
- **Embrace Asymmetry:** Place a `display-md` headline on the left and a small `body-md` paragraph slightly offset to the right. 
- **Use High-Contrast Scale:** Don't be afraid of the jump between `display-lg` and `body-sm`. This creates the "Editorial" look.
- **Smooth Transitions:** All hover states and page transitions must use a `cubic-bezier(0.4, 0, 0.2, 1)` timing function (Standard Ease) over 300ms to ensure a "calming" movement.

### Don't
- **Don't use pure black (#000000):** It is too harsh for this system. Use `on-surface` (#2f342e) for all text.
- **Don't crowd the edges:** Maintain a minimum page margin of `2rem` on mobile and `5rem` on desktop.
- **Don't use hard corners:** Every interactive element must have at least a `rounded-DEFAULT` (0.5rem) radius to stay within the "Soft & Relaxing" aesthetic.
- **Don't use 100% opaque outlines:** High-contrast borders shatter the "Ethereal Sanctuary" feel. Refer back to the Ghost Border fallback.